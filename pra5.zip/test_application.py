import pytest
import json
from application import application

@pytest.fixture
def client():
    application.config['TESTING'] = True
    with application.test_client() as client:
        yield client

def test_index(client):
    response = client.get('/')
    assert response.status_code == 200
    assert response.data.decode('utf-8') == "Your Flask App Works! V1.0"

def test_predict_no_text(client):
    response = client.post('/predict', data=json.dumps({}), content_type='application/json')
    assert response.status_code == 400
    assert 'No text provided' in response.data.decode('utf-8')

def test_predict_fake_news_1(client):
    response = client.post('/predict', data=json.dumps({'text': 'my cat can eat a dinansour'}), content_type='application/json')
    assert response.status_code == 200
    data = json.loads(response.data.decode('utf-8'))
    assert 'prediction' in data
    assert data['prediction'].lower() == 'fake'

def test_predict_fake_news_2(client):
    response = client.post('/predict', data=json.dumps({'text': 'garlic prevent cancers.'}), content_type='application/json')
    assert response.status_code == 200
    data = json.loads(response.data.decode('utf-8'))
    assert 'prediction' in data
    assert data['prediction'].lower() == 'fake'

def test_predict_real_news_1(client):
    response = client.post('/predict', data=json.dumps({'text': 'UofT is a University'}), content_type='application/json')
    assert response.status_code == 200
    data = json.loads(response.data.decode('utf-8'))
    assert 'prediction' in data
    assert data['prediction'].lower() == 'real'

def test_predict_real_news_2(client):
    response = client.post('/predict', data=json.dumps({'text': 'printer prints things'}), content_type='application/json')
    assert response.status_code == 200
    data = json.loads(response.data.decode('utf-8'))
    assert 'prediction' in data
    assert data['prediction'].lower() == 'real'